export default function toCamelCase(str?: string): string;
