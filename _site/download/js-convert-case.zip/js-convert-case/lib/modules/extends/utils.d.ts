export interface Options {
    recursive: boolean;
}
export declare const DefaultOption: Options;
export declare const isValidObject: (obj: any) => boolean;
