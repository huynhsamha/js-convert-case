export default function toHeaderCase(str?: string): string;
