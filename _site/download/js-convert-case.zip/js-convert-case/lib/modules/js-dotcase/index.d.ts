export default function toDotCase(str?: string): string;
