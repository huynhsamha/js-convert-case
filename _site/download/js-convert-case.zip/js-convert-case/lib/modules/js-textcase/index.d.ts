export default function toTextCase(str?: string): string;
