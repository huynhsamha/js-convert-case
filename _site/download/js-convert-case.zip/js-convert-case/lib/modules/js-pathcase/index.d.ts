export default function toPathCase(str?: string): string;
