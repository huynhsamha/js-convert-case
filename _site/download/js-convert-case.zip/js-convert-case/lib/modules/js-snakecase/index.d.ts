export default function toSnakeCase(str?: string): string;
