export default function toPascalCase(str?: string): string;
