export default function toSentenceCase(str?: string): string;
